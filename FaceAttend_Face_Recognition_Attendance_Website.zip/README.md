# FaceAttend — Face Recognition Attendance Website

## New project workflow

Faculty creates an attendance session → faculty shares the session link → student opens the link → student allows camera → student scans face → attendance is recorded → history is displayed.

## Included
- Faculty session creation
- Shareable student attendance link
- Student camera interface
- Face detection using face-api.js in the browser
- Student ID/name capture
- Duplicate attendance prevention
- Session expiry
- Persistent attendance history using localStorage
- Responsive UI

## Run

Open `index.html` in Chrome/Edge.

For camera access, browsers normally require a secure context (HTTPS) or localhost. If camera access does not work by opening the file directly, run a simple local server, for example:

Python:
    python -m http.server 8000

Then open:
    http://localhost:8000

## Important prototype note

This version performs browser-side face DETECTION (checks that a face is visible), not secure biometric IDENTIFICATION of which person the face belongs to.

A production face-recognition attendance system needs:
- Explicit consent and appropriate institutional/privacy policy
- Secure backend authentication
- Encrypted biometric-template storage if biometric identification is actually used
- Liveness / anti-spoofing
- Server-side verification
- Access control and audit logs
- A proper database such as PostgreSQL/MySQL

Do not treat the browser demo as a secure identity-verification system.
