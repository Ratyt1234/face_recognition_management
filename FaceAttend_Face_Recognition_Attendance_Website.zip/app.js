const DB="face_attendance_db_v1";
const seed={sessions:[],records:[]};
function getDB(){const x=localStorage.getItem(DB);if(!x){localStorage.setItem(DB,JSON.stringify(seed));return seed}return JSON.parse(x)}
function saveDB(x){localStorage.setItem(DB,JSON.stringify(x))}
function id(){return "SES_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,6)}
let activeSession=null, stream=null, modelsLoaded=false;

function scrollToId(id){document.getElementById(id)?.scrollIntoView({behavior:"smooth"})}
function createSession(){
 const d=getDB(); d.sessions.forEach(s=>s.active=false);
 const mins=Number(document.getElementById("duration").value);
 activeSession={id:id(),subject:document.getElementById("subject").value||"Class",faculty:document.getElementById("facultyName").value||"Faculty",createdAt:Date.now(),expiresAt:Date.now()+mins*60000,active:true};
 d.sessions.push(activeSession);saveDB(d);
 const link=location.href.split("#")[0]+"#student?session="+encodeURIComponent(activeSession.id);
 document.getElementById("sessionEmpty").classList.add("hidden");
 document.getElementById("sessionDetails").classList.remove("hidden");
 document.getElementById("sessionSubject").textContent=activeSession.subject;
 document.getElementById("sessionInfo").textContent="Valid for "+mins+" minutes · Expires "+new Date(activeSession.expiresAt).toLocaleTimeString();
 document.getElementById("sessionLink").textContent=link;
 document.getElementById("facultyMessage").innerHTML='<div class="msg ok">Attendance session created successfully.</div>';
 updateStudentSession(); renderHistory();
}
function copyLink(){navigator.clipboard?.writeText(document.getElementById("sessionLink").textContent);document.getElementById("facultyMessage").innerHTML='<div class="msg ok">Student link copied.</div>'}
function openStudent(){scrollToId("student");updateStudentSession()}
function updateStudentSession(){
 const d=getDB();let s=activeSession||d.sessions.slice().reverse().find(x=>x.active&&x.expiresAt>Date.now());
 if(s){activeSession=s;document.getElementById("studentSessionName").textContent=s.subject;document.getElementById("studentSessionInfo").textContent="Session active · Expires "+new Date(s.expiresAt).toLocaleTimeString()}
}
async function startCamera(){
 const status=document.getElementById("cameraStatus");
 try{
  stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"},audio:false});
  document.getElementById("video").srcObject=stream;status.textContent="Camera active";
  await loadModels();
 }catch(e){status.textContent="Camera permission required";document.getElementById("scanMessage").innerHTML='<div class="msg bad">Camera access was not available. Allow camera permission and try again.</div>'}
}
async function loadModels(){
 if(modelsLoaded)return true;
 try{
  statusText("Loading face detection model...");
  const base="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/weights";
  await faceapi.nets.tinyFaceDetector.loadFromUri(base);
  modelsLoaded=true;statusText("Face detection ready");
  return true;
 }catch(e){statusText("Demo scan mode ready");return false}
}
function statusText(t){document.getElementById("cameraStatus").textContent=t}
async function scanFace(){
 const msg=document.getElementById("scanMessage"),name=document.getElementById("studentName").value.trim(),sid=document.getElementById("studentId").value.trim();
 updateStudentSession();const d=getDB(),s=activeSession;
 if(!s||!s.active||s.expiresAt<Date.now()){msg.innerHTML='<div class="msg bad">No active attendance session. Ask faculty for the current link.</div>';return}
 if(!name||!sid){msg.innerHTML='<div class="msg bad">Enter your student name and ID before scanning.</div>';return}
 if(d.records.some(r=>r.sessionId===s.id&&r.studentId.toLowerCase()===sid.toLowerCase())){msg.innerHTML='<div class="msg bad">Attendance already recorded for this student in this session.</div>';return}
 let detected=true;
 if(window.faceapi&&modelsLoaded){
  const video=document.getElementById("video");
  if(!stream){msg.innerHTML='<div class="msg bad">Start the camera first.</div>';return}
  const result=await faceapi.detectSingleFace(video,new faceapi.TinyFaceDetectorOptions({inputSize:224,scoreThreshold:.5}));
  detected=!!result;
 }
 if(!detected){msg.innerHTML='<div class="msg bad">No face detected. Move into the frame and try again.</div>';return}
 d.records.push({id:id(),sessionId:s.id,studentId:sid,studentName:name,subject:s.subject,timestamp:Date.now(),status:"Present"});
 saveDB(d);msg.innerHTML='<div class="msg ok"><strong>Attendance recorded.</strong> Face scan completed successfully.</div>';renderHistory();
}
function renderHistory(){
 const d=getDB(),body=document.getElementById("historyBody"),count=document.getElementById("historyCount");if(!body)return;
 count.textContent=d.records.length;
 if(!d.records.length){body.innerHTML='<tr><td colspan="6" class="empty">No attendance records yet.</td></tr>';return}
 body.innerHTML=d.records.slice().reverse().map(r=>`<tr><td>${esc(r.studentName)}</td><td>${esc(r.studentId)}</td><td>${esc(r.subject)}</td><td>${new Date(r.timestamp).toLocaleDateString()}</td><td>${new Date(r.timestamp).toLocaleTimeString()}</td><td class="status-pill">✓ Present</td></tr>`).join("");
}
function clearHistory(){if(confirm("Clear all demo attendance records?")){const d=getDB();d.records=[];saveDB(d);renderHistory()}}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
document.addEventListener("DOMContentLoaded",()=>{renderHistory();updateStudentSession();});
